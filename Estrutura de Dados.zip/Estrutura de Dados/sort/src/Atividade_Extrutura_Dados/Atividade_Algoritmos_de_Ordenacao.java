package Atividade_Extrutura_Dados;

import java.util.Scanner;
import java.io.IOException;

public class Atividade_Algoritmos_de_Ordenacao {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        
        int quantidade = 10000;
        int[] vetor = new int[quantidade];
        for (int i = 0; i< vetor.length; i++){ 
            vetor[i] = (int) (Math.random() * quantidade);
        }
        System.out.println("Digite o seu nome para começar: \n");
        String nome = sc.nextLine();
        System.out.println("Seja bem-vindo, "+nome+"\n");
        int valorDigitado;

        do{
            System.out.println("=== ATIVIDADE INSERTION SORT === \n");
            System.out.println("Alunos: Alexandre Chagas, Arthur Cavalcante, Edenilson Lima e Pedro Lucas");
            System.out.println("Digite uma das opções abaixo: ");
            System.out.println("1 - Algoritmo de Ordenação - INSERTION SORT");
            System.out.println("2 - Algoritmo de Ordenação - BUBBLE SORT");
            System.out.println("3 - Algoritmo de Ordenação - SELECTION SORT");
            System.out.println("4 - Algoritmo de Ordenação - QUICK SORT");
            System.out.println("0 - Sair");
            valorDigitado = Integer.parseInt(sc.nextLine());
        
            long tempoInicial = System.currentTimeMillis();
            switch (valorDigitado){
                case 1:
                    {
                    System.out.println("\n INSERTION \n");
                    insertionSort(vetor);
                    long tempoFinal =System.currentTimeMillis();
                    System.out.println("Executado em = " + (tempoFinal - tempoInicial) + "ms \n");
                    break;
                    }
                        
                case 2:
                    {
                    System.out.println("\n BUBBLE \n");
                    bubbleSort(vetor);
                    long tempoFinal =System.currentTimeMillis();
                    System.out.println("Executado em = " + (tempoFinal - tempoInicial) + "ms \n");
                    break;
                    }
                    
                case 3:
                    {
                    System.out.println("\n SELECTION \n");
                    selectionSort(vetor);
                    long tempoFinal =System.currentTimeMillis();
                    System.out.println("Executado em = " + (tempoFinal - tempoInicial) + "ms \n");
                    break;
                    }
                
                case 4:
                    {
                    System.out.println("\n QUICK \n");
                    quickSort(vetor,0,vetor.length-1);
                    long tempoFinal =System.currentTimeMillis();
                    System.out.println("Executado em = " + (tempoFinal - tempoInicial) + "ms \n");
                    break;
                    }  
                    
                default:
                    System.out.println("\nQue pena, "+nome+" volte sempre.\n");
                    System.out.println("=== Fim do Programa ===");
                    break;
                        }
        }while(valorDigitado !=0);
    }
             
    public static void insertionSort(int[] vetor) {
            int j;
            int key;
            int i;
            
            vetor[9]=10;
            vetor[0]=6;
            vetor[1]=7;
            vetor[2]=3;
            vetor[3]=4;
            vetor[4]=8;
            vetor[5]=9;
            vetor[6]=2;
            vetor[7]=1;
            vetor[8]=5;
            
            for (j = 1; j < vetor.length; j++)
            {
               key = vetor[j];
               for (i = j -1; (i >=0) && (vetor[i]> key); i--)
               {
                 vetor[i + 1] = vetor[i];
               }
               vetor [i+1] = key;
              
               System.out.println(vetor[9]+" " +vetor[8]+" " +  vetor[7]+" " +  
                vetor[6]+" " +  vetor[5]+" " +  vetor[4]+" " +  vetor[3]+" " +  
                vetor[2]+" " + vetor[1]+" " + vetor[0]);
            }
    }
   
    public static void bubbleSort(int[] vetor) {
        boolean troca = true;
        int aux;
        
        vetor[9]=10;
        vetor[0]=6;
        vetor[1]=7;
        vetor[2]=3;
        vetor[3]=4;
        vetor[4]=8;
        vetor[5]=9;
        vetor[6]=2;
        vetor[7]=1;
        vetor[8]=5;
        
        while (troca) {
            troca = false;
            for (int i = 0; i < vetor.length - 1; i++) {
                if (vetor[i] > vetor[i + 1]) {
                    aux = vetor[i];
                    vetor[i] = vetor[i + 1];
                    vetor[i + 1] = aux;
                    troca = true;
                 System.out.println(vetor[9]+" " +vetor[8]+" " +  vetor[7]+" " +  
                  vetor[6]+" " +  vetor[5]+" " +  vetor[4]+" " +  vetor[3]+" " +  
                  vetor[2]+" " + vetor[1]+" " + vetor[0]);
                 
                   
                }
            }
        }
    }
    
    public static void selectionSort(int[] vetor) {
        for (int fixo = 0; fixo < vetor.length - 1; fixo++){
            int menor = fixo;
            //int[] vetor = null;
            
            vetor[9]=10;
            vetor[0]=6;
            vetor[1]=7;
            vetor[2]=3;
            vetor[3]=4;
            vetor[4]=8;
            vetor[5]=9;
            vetor[6]=2;
            vetor[7]=1;
            vetor[8]=5;
            
            for (int i = menor + 1; i < vetor.length; i++){
                if (vetor[i] < vetor[menor]){
                    menor = i;
                } 
            }
            if  (menor != fixo) {
                int t = vetor[fixo];
                System.out.println(vetor[9]+" " +vetor[8]+" " +  vetor[7]+" " +  
                 vetor[6]+" " +  vetor[5]+" " +  vetor[4]+" " +  vetor[3]+" " +  
                 vetor[2]+" " + vetor[1]+" " + vetor[0]);
            }
        }
    }
    
    private static void quickSort(int[] vetor, int inicio, int fim){
        if(inicio < fim){
            int posicaoPivo = separar(vetor, inicio, fim);
            quickSort(vetor, inicio, posicaoPivo -1);
            quickSort(vetor, posicaoPivo + 1, fim);
        }
    }
    private static int separar(int[] vetor, int inicio, int fim){
        int pivo = vetor[inicio];
        int i =inicio + 1, f=fim;
            
        vetor[9]=10;
        vetor[0]=6;
        vetor[1]=7;
        vetor[2]=3;
        vetor[3]=4;
        vetor[4]=8;
        vetor[5]=9;
        vetor[6]=2;
        vetor[7]=1;
        vetor[8]=5;
        
        while (i <= f) {
            if (vetor[i] <= pivo)
                i++;
            else if (pivo < vetor[f])
                f--;
            else {
                int troca = vetor[i];
                vetor[i] = vetor[f];
                vetor[f] = troca;
                i++;
                f--;
                
                System.out.println(vetor[9]+" " +vetor[8]+" " +  vetor[7]+" " +  
                 vetor[6]+" " +  vetor[5]+" " +  vetor[4]+" " +  vetor[3]+" " +  
                 vetor[2]+" " + vetor[1]+" " + vetor[0]);
            }
        }
        vetor[inicio] = vetor[f];
        vetor[f] = pivo;
        return f;
    }
}